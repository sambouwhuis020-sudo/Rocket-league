# 🚀 Rocket League Browser Edition

Een volledig speelbare Rocket League clone in de browser.

## Spelen
Ga naar: `https://JOUWGEBRUIKERSNAAM.github.io/REPONAAM`

## Besturing
- **W** = Gas | **S** = Rem | **A/D** = Sturen
- **SPACE** = Springen | **B** = Boost

## Features
- 5 auto's, 8 modi, 5 stadions, ranked systeem, touch controls
