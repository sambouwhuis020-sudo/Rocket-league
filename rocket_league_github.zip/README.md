# 🚀 Rocket League Browser Edition

Een volledig speelbare Rocket League clone in de browser, gebouwd met HTML5 Canvas.

## 🎮 Spelen

Ga naar: **https://JOUWGEBRUIKERSNAAM.github.io/rocket-league**

Of open `index.html` lokaal in je browser.

## 🕹️ Besturing

| Toets | Actie |
|-------|-------|
| W | Gas geven |
| S | Remmen / achteruit |
| A | Links sturen |
| D | Rechts sturen |
| SPACE | Springen |
| B | Boost |

## ✨ Features

- 5 carrosseries: Octane, Dominus, Fennec, Breakout, Merc
- 8 game modi: 1v1, 2v2, 3v3, 4v4, Heatseeker, Snow Day, Rumble, Hoops
- 5 stadions: Beckwith Park, Urban Central, Aquadome, Neon Fields, Arctic Exchange
- Ranked systeem met 4 ranks (Bronze → Diamond)
- 3 AI moeilijkheden: Easy, Hard, Impossible
- Ballcam, quickchat, goal explosies
- Touch controls voor mobiel / iPad

## 🚀 Zelf hosten op GitHub Pages

1. Fork of upload deze repository
2. Ga naar **Settings → Pages**
3. Zet Source op **main branch / root**
4. Je site is live op `https://JOUWGEBRUIKERSNAAM.github.io/REPONAAM`
